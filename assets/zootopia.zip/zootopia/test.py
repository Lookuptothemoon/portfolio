class Suspect(object):
	def __init__(self, nm):
		self.name = nm
	def first_name(self):
		first_name = (self.name).split(' ', 1)[0]
		return first_name

class Location(object):
	def __init__(self, s1, s2, cm):
		self.ssp1 = s1
		self.ssp1 = s2
		self.crmnl = cm
	def enter(self):
		print "You have entered this level!"
		exit(1)

class TheBurrows(Location):
	suspect_1 = Suspect("Sterny Sr. the Squirrel")
	suspect_2 = Suspect("Stella the Squirrel")
	criminal = Suspect("Sylvia the Squirrel")
	def __init__(self):
		super(TheBurrows, self).__init__(self.suspect_1, self.suspect_2, self.criminal)
	
	def enter(self):
		print """
			One upon a time, there was a squirrel named Sterny. 
			Sterny was excited because he had just been given a stack of golden acorns from his father, 
			which had been given to him by his father, which had been given to him by his father and so on.
			Unfortunately, one night, when Sterny was asleep, a gang of predators snuck into Sterny's house and stole his acorns stash. 
			When Sterny awoke the next day, he was devastated. 
			'MY ACORNS ARE GONE! SOMEONE STOLE THEM!', Sterny said in shock.
			'I WILL FIND WHOEVER STOLE THEM AND MAKE THEM PAY!'
		"""
		raw_input("Press any key to continue\n")
		
		print """			
			He decided he was going to search the entire city to find his acorns.
			He figured he would start where he was, the Burrows.
			He suspected three people might be the criminal.
			"""
		raw_input("Press any key to continue\n")
		
		print """
			Suspect #1: Sterny Sr.
				When Sterny looked at his drawer, where he kept his acorns, he saw a trail of dandruff leading to his grandpa's room.
			"""
		raw_input("Press any key to continue\n")
		
		print """
			Suspect #2: Sylvia
				He remembered catching his sister in his drawer several times without his permission.
			"""
		raw_input("Press any key to continue\n")
		
		print """
			Suspect #3: Stella
				His aunt cleans his room on the daily basis and often complains about having financial issues.
				She could 
			"""
		
		cont = True
		while cont==True:
			print "\nWho do you suspect the criminal is?"
			choice = raw_input("> ")
			if choice == self.criminal.first_name():
				print "Congrats, you just retrieved one of Sterny's golden acorns."
				cont = False
			elif choice==self.suspect_1.first_name() or choice==self.suspect_2.first_name():
				print "That was wrong. You would not make a great detective."
				cont = False
			else:
				print "Sorry, that was an invalid input"
		
		

TheBurrows().enter()