To run:
Open terminal to zootopia.py file and ruun command
$python3 zootopia.py