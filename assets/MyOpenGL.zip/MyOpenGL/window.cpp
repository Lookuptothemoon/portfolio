// window.cpp

#include <QtWidgets>
#include <QPixmap>
#include <string>
#include "window.h"
#include "ui_window.h"

#include "myglwidget.h"

Window::Window(QWidget *parent) : QWidget(parent), ui(new Ui::Window)

{
    ui->setupUi(this);

    // rotation sliders
    connect( ui->myGLWidget, SIGNAL(xRotationChanged(int)), ui->rotXSlider, SLOT(setValue(int)) );
    connect( ui->myGLWidget, SIGNAL(yRotationChanged(int)), ui->rotYSlider, SLOT(setValue(int)) );
    connect( ui->myGLWidget, SIGNAL(zRotationChanged(int)), ui->rotZSlider, SLOT(setValue(int)) );
    // shape buttons
    connect( ui->myGLWidget, SIGNAL(shapeChanged()), ui->cubeBtn, SLOT(setCube()) );
    connect( ui->myGLWidget, SIGNAL(shapeChanged()), ui->pyramidBtn, SLOT(setPyramid()) );
    connect( ui->myGLWidget, SIGNAL(shapeChanged()), ui->rectBtn, SLOT(setRect()) );
    connect( ui->myGLWidget, SIGNAL(shapeChanged()), ui->noneBtn, SLOT(setNone()) );
    // color button
    connect( ui->myGLWidget, SIGNAL(colorChanged()), ui->colorBtn, SLOT(setColor()) );
    // dimension spin boxes
    connect( ui->myGLWidget, SIGNAL(sizeChanged(double)), ui->size_val, SLOT(setSize(double)) );
    connect( ui->myGLWidget, SIGNAL(baseChanged(double)), ui->base_val, SLOT(setBase(double)) );
    connect( ui->myGLWidget, SIGNAL(heightChanged(double)), ui->height_val, SLOT(setHeight(double)) );
    connect( ui->myGLWidget, SIGNAL(lengthChanged(double)), ui->length_val, SLOT(setLength(double)) );
    connect( ui->myGLWidget, SIGNAL(WidthChanged(double)), ui->width_val, SLOT(setWidth(double)) );
    // download button
    connect( ui->myGLWidget, SIGNAL(downloaded()), ui->downloadBtn, SLOT(initDownload()) );
    // undo button
    connect( ui->myGLWidget, SIGNAL(undo()), ui->undoBtn, SLOT(initUndo()) );

    // add background images to shape buttons
    ui->cubeBtn->setStyleSheet("border-image:url(:/MyOpenGL/cube);");
    ui->pyramidBtn->setStyleSheet("border-image:url(:/MyOpenGL/pyramid);");
    ui->rectBtn->setStyleSheet("border-image:url(:/MyOpenGL/rect);");
    ui->undoBtn->setStyleSheet("border-image:url(:/MyOpenGL/undo);");

    //ui->downloadBtn->hide();
}

Window::~Window()
{
    delete ui;
}
