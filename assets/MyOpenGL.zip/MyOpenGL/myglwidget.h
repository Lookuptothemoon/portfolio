// myglwidget.h

#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#include <QGLWidget>
#include <string>

class MyGLWidget : public QGLWidget
{
    Q_OBJECT
public:
    explicit MyGLWidget(QWidget *parent = 0);
    ~MyGLWidget();
signals:

public slots:

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);

    QSize minimumSizeHint() const;
    QSize sizeHint() const;
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    // key press events
    void keyPressEvent(QKeyEvent *e);


public slots:
    // slots for xyz-rotation slider
    void setXRotation(int angle);
    void setYRotation(int angle);
    void setZRotation(int angle);
    // slots for shape buttons
    void setCube();
    void setPyramid();
    void setRect();
    void setNone();
    // slots for shape colors
    void setColor();
    // slots for dimensions
    void setLength(double mag);
    void setWidth(double mag);
    void setHeight(double mag);
    void setBase(double mag);
    void setSize(double mag);
    // slot for download button
    void initDownload();
    // slot for undo button
    void initUndo();

signals:
    // signaling rotation from mouse movement
    void xRotationChanged(int angle);
    void yRotationChanged(int angle);
    void zRotationChanged(int angle);
    // signaling shapes
    void shapeChanged();
    // signaling shape colors
    void colorChanged();
    // signal dimension changed
    void lengthChanged(double mag);
    void widthChanged(double mag);
    void heightChanged(double mag);
    void baseChanged(double mag);
    void sizeChanged(double mag);
    // signal download button
    void downloaded();
    // signal undo button
    void undo();

private:
    void drawCube(GLfloat mag, QColor c, GLfloat offset);
    void drawPyramid(QColor c, GLfloat offset);
    void drawRect(GLfloat h, GLfloat l, GLfloat w, QColor c, GLfloat offset);
    void draw();

    // private vars
    QWidget *parent_widget;
    double x;
    double y;
    double z;
    int xRot;
    int yRot;
    int zRot;
    QPoint lastPos;

    std::string shape;
    QColor color;
};

#endif // MYGLWIDGET_H

