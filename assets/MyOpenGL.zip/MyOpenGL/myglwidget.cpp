// myglwidget.cpp

#include <QtWidgets>
#include <QtOpenGL>
#include <string>
#include <deque>
#include <fstream>

#include "myglwidget.h"

/* STRUCTS */
// pyramid struct
typedef struct{
    GLfloat base;
    GLfloat height;
} pyramid;
// cube struct
typedef struct{
    GLfloat size;
} cube;
// rectangular prism struct
typedef struct{
    GLfloat length;
    GLfloat width;
    GLfloat height;
} rect;
// shape struct
typedef union{
    pyramid pyramid;
    cube cube;
    rect rect;
} shape;

// shape specs to draw
typedef struct l{
    std::string type;
    shape shape;
    QColor color;
} Level;

// deque of levels
std::deque<Level> shapes;



// length, width, height, size, ... vars
double curr_length = 0.4;
double curr_width = 0.6;
double curr_height = 0.1;
double curr_size = 0.2;
double curr_base = 0.0;



MyGLWidget::MyGLWidget(QWidget *parent) : QGLWidget(QGLFormat(QGL::SampleBuffers), parent) {
    parent_widget = parent;
    x = 0;
    y = 0;
    z = 0;
    xRot = 0;
    yRot = 0;
    zRot = 0;
    shape = "";
    color = Qt::red;
}

MyGLWidget::~MyGLWidget(){}


// initialize
void MyGLWidget::initializeGL(){
    qglClearColor(Qt::black);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glShadeModel(GL_SMOOTH);
    //glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    // set light intensity for x, y, z
    static GLfloat lightPosition[4] = { 1, 7, 3, 1.0 };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
}

// draw GL
void MyGLWidget::paintGL(){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glTranslatef(x, y, z);
    glRotatef( xRot/2, 1.0, 0.0, 0.0);
    glRotatef( yRot/2, 0.0, 1.0, 0.0);
    glRotatef( zRot/2, 0.0, 0.0, 1.0);
    draw();
}

// update GL size
void MyGLWidget::resizeGL(int width, int height){
    int side = qMin(width, height);
    glViewport( (width-side)/2, (height-side)/2, side, side);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
#ifdef QT_OPENGL_ES_1
    glOrthof(-2, +2, -2, +2, 1.0, 15.0);
#else
    glOrtho(-2, +2, -0.5, +2, 1.0, -15.0);
#endif
    glMatrixMode(GL_MODELVIEW);
}

// Not working!
QSize MyGLWidget::minimumSizeHint() const{
    return QSize(50, 50);
}

// set size of window on startup
QSize MyGLWidget::sizeHint() const{
    return QSize(400, 400);
}

// draw cube of color
void MyGLWidget::drawCube(GLfloat mag, QColor c, GLfloat offset){
        // top
        glBegin(GL_QUADS);
        qglColor(c);
        glNormal3f(0.0f, 1.0f, 0.0f);
        glVertex3f(-mag, mag, (mag*2)+offset);
        glVertex3f(mag, mag, (mag*2)+offset);
        glVertex3f(mag, mag, offset);
        glVertex3f(-mag, mag, offset);
        glEnd();

        // front
        glBegin(GL_QUADS);
        qglColor(c);
        glNormal3f(0.0f, 0.0f, 1.0f);
        glVertex3f(mag, -mag, (mag*2)+offset);
        glVertex3f(mag, mag, (mag*2)+offset);
        glVertex3f(-mag, mag, (mag*2)+offset);
        glVertex3f(-mag, -mag, (mag*2)+offset);
        glEnd();

        // right
        glBegin(GL_QUADS);
        qglColor(c);
        glNormal3f(1.0f, 0.0f, 0.0f);
        glVertex3f(mag, mag, offset);
        glVertex3f(mag, mag, (mag*2)+offset);
        glVertex3f(mag, -mag, (mag*2)+offset);
        glVertex3f(mag, -mag, offset);
        glEnd();

        // left
        glBegin(GL_QUADS);
        qglColor(c);
        glNormal3f(-1.0f, 0.0f, 0.0f);
        glVertex3f(-mag, -mag, (mag*2)+offset);
        glVertex3f(-mag, mag, (mag*2)+offset);
        glVertex3f(-mag, mag, offset);
        glVertex3f(-mag, -mag, offset);
        glEnd();

        // bottom
        glBegin(GL_QUADS);
        qglColor(c);
        glNormal3f(0.0f, -1.0f, 0.0f);
        glVertex3f(mag, -mag, (mag*2)+offset);
        glVertex3f(-mag, -mag, (mag*2)+offset);
        glVertex3f(-mag, -mag, offset);
        glVertex3f(mag, -mag, offset);
        glEnd();

        // back
        glBegin(GL_QUADS);
        qglColor(c);
        glNormal3f(0.0f, 0.0f, -1.0f);
        glVertex3f(mag, mag, offset);
        glVertex3f(mag, -mag, offset);
        glVertex3f(-mag, -mag, offset);
        glVertex3f(-mag, mag, offset);
        glEnd();

            /*
            // top
            glBegin(GL_QUADS);
            qglColor(Qt::yellow);
            //glNormal3f(0.0f, (mag*2)+offset, 0.0f);
            glVertex3f(-mag, (mag*2)+offset, -mag);
            glVertex3f(mag, (mag*2)+offset, -mag);
            glVertex3f(-mag, (mag*2)+offset, mag);
            glVertex3f(mag, (mag*2)+offset, mag);
            glEnd();

            // front
            glBegin(GL_QUADS);
            qglColor(Qt::blue);
            //glNormal3f(0.0f, mag+offset, mag);
            glVertex3f(-mag, offset, mag);
            glVertex3f(mag, offset, mag);
            glVertex3f(-mag, (mag*2)+offset, mag);
            glVertex3f(mag, (mag*2)+offset, mag);
            glEnd();

            // right
            glBegin(GL_QUADS);
            qglColor(c);
            //glNormal3f(mag, mag+offset, 0.0f);
            glVertex3f(mag, offset, mag);
            glVertex3f(mag, offset, -mag);
            glVertex3f(mag, (mag*2)+offset, mag);
            glVertex3f(mag, (mag*2)+offset, -mag);
            glEnd();

            // left
            glBegin(GL_QUADS);
            qglColor(c);
            //glNormal3f(-mag, mag+offset, 0.0f);
            glVertex3f(-mag, offset, mag);
            glVertex3f(-mag, offset, -mag);
            glVertex3f(-mag, (mag*2)+offset, mag);
            glVertex3f(-mag, (mag*2)+offset, -mag);
            glEnd();

            // bottom
            glBegin(GL_QUADS);
            qglColor(c);
            //glNormal3f(0.0f, offset, 0.0f);
            glVertex3f(-mag, offset, -mag);
            glVertex3f(mag, offset, -mag);
            glVertex3f(-mag, offset, mag);
            glVertex3f(mag, offset, mag);
            glEnd();

            // back
            glBegin(GL_QUADS);
            qglColor(c);
            //glNormal3f(0.0f, mag+offset, -mag);
            glVertex3f(-mag, offset, -mag);
            glVertex3f(mag, offset, -mag);
            glVertex3f(-mag, (mag*2)+offset, -mag);
            glVertex3f(mag, (mag*2)+offset, -mag);
            glEnd();
            */
}

void MyGLWidget::drawPyramid(QColor c, GLfloat offset){
    glBegin(GL_QUADS);
        qglColor(c);
        glNormal3f(0,0,-1+offset);
        glVertex3f(-1,-1,0+offset);
        glVertex3f(-1,1,0+offset);
        glVertex3f(1,1,0+offset);
        glVertex3f(1,-1,0+offset);
    glEnd();

    glBegin(GL_TRIANGLES);
        qglColor(c);
        glNormal3f(0,-1,0.707+offset);
        glVertex3f(-1,-1,offset);
        glVertex3f(1,-1,offset);
        glVertex3f(0,0,1.2+offset);
    glEnd();

    glBegin(GL_TRIANGLES);
        qglColor(c);
        glNormal3f(1,0, 0.707+offset);
        glVertex3f(1,-1,offset);
        glVertex3f(1,1,offset);
        glVertex3f(0,0,1.2+offset);
    glEnd();

    glBegin(GL_TRIANGLES);
        qglColor(c);
        glNormal3f(0,1,0.707+offset);
        glVertex3f(1,1,offset);
        glVertex3f(-1,1,offset);
        glVertex3f(0,0,1.2+offset);
    glEnd();

    glBegin(GL_TRIANGLES);
        qglColor(c);
        glNormal3f(-1,0,0.707+offset);
        glVertex3f(-1,1,0+offset);
        glVertex3f(-1,-1,0+offset);
        glVertex3f(0,0,1.2+offset);
    glEnd();
}

void MyGLWidget::drawRect(GLfloat h, GLfloat l, GLfloat w, QColor c, GLfloat offset){
    glBegin(GL_QUADS);
    // top
    qglColor(c);
    glNormal3f(0.0f, 1.0f, 0.0f);
    glVertex3f(-w, l, (h*2)+offset);
    glVertex3f(w, l, (h*2)+offset);
    glVertex3f(w, l, offset);
    glVertex3f(-w, l, offset);
    glEnd();

    glBegin(GL_QUADS);
    // front
    qglColor(c);
    glNormal3f(0.0f, 0.0f, 1.0f);
    glVertex3f(w, -l, (h*2)+offset);
    glVertex3f(w, l, (h*2)+offset);
    glVertex3f(-w, l, (h*2)+offset);
    glVertex3f(-w, -l, (h*2)+offset);
    glEnd();

    glBegin(GL_QUADS);
    // right
    qglColor(c);
    glNormal3f(1.0f, 0.0f, 0.0f);
    glVertex3f(w, l, offset);
    glVertex3f(w, l, (h*2)+offset);
    glVertex3f(w, -l, (h*2)+offset);
    glVertex3f(w, -l, offset);
    glEnd();

    glBegin(GL_QUADS);
    // left
    qglColor(c);
    glNormal3f(-1.0f, 0.0f, 0.0f);
    glVertex3f(-w, -l, (h*2)+offset);
    glVertex3f(-w, l, (h*2)+offset);
    glVertex3f(-w, l, offset);
    glVertex3f(-w, -l, offset);
    glEnd();

    glBegin(GL_QUADS);
    // bottom
    qglColor(c);
    glNormal3f(0.0f, -1.0f, 0.0f);
    glVertex3f(w, -l, (h*2)+offset);
    glVertex3f(-w, -l, (h*2)+offset);
    glVertex3f(-w, -l, offset);
    glVertex3f(w, -l, offset);
    glEnd();

    glBegin(GL_QUADS);
    // back
    qglColor(c);
    glNormal3f(0.0f, 0.0f, -1.0f);
    glVertex3f(w, l, offset);
    glVertex3f(w, -l, offset);
    glVertex3f(-w, -l, offset);
    glVertex3f(-w, l, offset);
    glEnd();
}

// draw shape
void MyGLWidget::draw(){
    // loop through shapes
    GLfloat off = 0.0f;
    for(auto it=shapes.begin(); it!=shapes.end(); ++it){
        Level i = *it;
        if( i.type == "cube" ){
            drawCube(i.shape.cube.size/2, i.color, off);
            off += i.shape.cube.size;
        }else if( i.type == "pyramid" ){
            drawPyramid(i.color, off);
            off += 1.2f;
        }else if( i.type == "rect" ){
            drawRect(i.shape.rect.height/2, i.shape.rect.length/2, i.shape.rect.width/2, i.color, off);
            off += i.shape.rect.height;
        }
    }
}



/* SET ROTATION */
static void qNormalizeAngle(int &angle){
    while (angle < 0)
        angle += 360 * 10;
    while (angle > 360)
        angle -= 360 * 10;
}

void MyGLWidget::setXRotation(int angle){
    qNormalizeAngle(angle);
    if (angle != xRot) {
        xRot = angle;
        emit xRotationChanged(angle);
        updateGL();
    }
}

void MyGLWidget::setYRotation(int angle){
    qNormalizeAngle(angle);
    if (angle != yRot) {
        yRot = angle;
        emit yRotationChanged(angle);
        updateGL();
    }
}

void MyGLWidget::setZRotation(int angle){
    qNormalizeAngle(angle);
    if (angle != zRot) {
        zRot = angle;
        emit zRotationChanged(angle);
        updateGL();
    }
}



/* SET SHAPES */
// set cube
void MyGLWidget::setCube(){
    printf("cube clicked\n");
    if(shape != "cube")
        shape = "cube";
    // add cube to list of shapes
    Level l;
    l.type = shape;
    l.shape.cube.size = curr_size;
    l.color = color;
    shapes.push_back(l);

    // send signal
    emit shapeChanged();
    updateGL();
}

// set pyramid
void MyGLWidget::setPyramid(){
    printf("pyramid clicked\n");
    if(shape != "pyramid")
        shape = "pyramid";
    // add pyramid to list of shapes
    Level l;
    l.type = shape;
    l.shape.pyramid.base = curr_base;
    l.shape.pyramid.height = curr_height;
    l.color = color;
    shapes.push_back(l);

    // send signal
    emit shapeChanged();
    updateGL();
}

// set rectangle
void MyGLWidget::setRect(){
    printf("rect clicked\n");
    if(shape != "rect")
        shape = "rect";
    // add rect to list of shapes
    Level l;
    l.type = shape;
    l.shape.rect.length = curr_length;
    l.shape.rect.width = curr_width;
    l.shape.rect.height = curr_height;
    l.color = color;
    shapes.push_back(l);

    // send signal
    emit shapeChanged();
    updateGL();
}

// set none
void MyGLWidget::setNone(){
    printf("none clicked\n");
    if(shape != "")
        shape = "";
    // clear list of shapes
    shapes.clear();

    emit shapeChanged();
    updateGL();
}



/* SET SHAPE COLOR */
// set color
void MyGLWidget::setColor(){
    QColor  c = QColorDialog::getColor(color, this);
    color = c;
    qDebug() << "color name is: " << color.name() << "\n";
    emit colorChanged();
    updateGL();
}



/* SET DIMENSIONS */
// set length
void MyGLWidget::setLength(double mag){
    if( curr_length != mag )
        curr_length = mag;
    printf("current length is %f\n", curr_length);
    emit lengthChanged(mag);
    updateGL();
}

// set width
void MyGLWidget::setWidth(double mag){
    if( curr_width != mag )
        curr_width = mag;
    printf("current width is %f\n", curr_width);
    emit widthChanged(mag);
    updateGL();
}

// set height
void MyGLWidget::setHeight(double mag){
    if( curr_height != mag )
        curr_height = mag;
    printf("current height is %f\n", curr_height);
    emit heightChanged(mag);
    updateGL();
}

// set base
void MyGLWidget::setBase(double mag){
    if(curr_base != mag)
        curr_base = mag;
    printf("current base is %f\n", curr_base);
    emit baseChanged(mag);
    updateGL();
}

// set size
void MyGLWidget::setSize(double mag){
    if(curr_size != mag)
        curr_size = mag;
    printf("current base is %f\n", curr_size);
    emit sizeChanged(mag);
    updateGL();
}



/* SET DOWNLOAD */
void MyGLWidget::initDownload(){
    printf("downloading ...\n");
    // get user input for file name and location
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    tr("Save 3D Object"), "/Users/lookuptothemoon/Documents/Columbia/Spring-2020/Food-Printing/Qt-Practice/MyOpenGL/downloaded",
                                                    tr("STL File (*.stl);;All Files (*)"));
    // check if file has content
    if(fileName.isEmpty())
        return;
    else{
        // check if file can be opened for writing
        std::ofstream out;
        out.open(fileName.toStdString());
        /*
        QFile file(fileName);
        if(!file.open(QIODevice::WriteOnly)){
            QMessageBox::information(this, tr("unable to open file"),
                                     file.errorString());
            return;
        }
        */

        /* WRITE SHAPES TO STL FILE */
        //QDataStream out(&file);
        //out.setVersion(QDataStream::Qt_4_5);

        // loop through shapes
        /*
        GLfloat offset = 0.0f;
        for(auto it=shapes.begin(); it!=shapes.end(); ++it){
            Level i = *it;
            if( i.type == "cube" ){
                // draw cube
                GLfloat mag = i.shape.cube.size/2;
                out << "solid cube\n";
                // top
                out << " facet normal " << 0.0f << " " << 1.0f << " " << 0.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << " endfacet" << std::endl;
                out << "facet normal " << 0.0f << " " << 1.0f << " " << 0.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << offset << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                // front
                out << "facet normal " << 0.0f << " " << 0.0f << " " << 1.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << (mag*2)+offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                out << "facet normal " << 0.0f << " " << 0.0f << " " << 1.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                // right
                out << "facet normal " << 1.0f << " " << 0.0f << " " << 0.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << offset << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                out << "facet normal " << 1.0f << " " << 0.0f << " " << 0.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << offset << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                // left
                out << "facet normal " << -1.0f << " " << 0.0f << " " << 0.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                out << "facet normal " << -1.0f << " " << 0.0f << " " << 0.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << offset << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                // bottom
                out << "facet normal " << 0.0f << " " << -1.0f << " " << 0.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                out << "facet normal " << 0.0f << " " << -1.0f << " " << 0.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << (mag*2)+offset << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << offset << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                // back
                out << "facet normal " << 0.0f << " " << 0.0f << " " << -1.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << offset << std::endl;
                out << "\t\tvertex " << mag << " " << -mag << " " << offset << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "endfacet" << std::endl;
                out << "facet normal " << 0.0f << " " << 0.0f << " " << -1.0f << std::endl;
                out << "\touter loop" << std::endl;
                out << "\t\tvertex " << mag << " " << mag << " " << offset << std::endl;
                out << "\t\tvertex " << -mag << " " << -mag << " " << offset << std::endl;
                out << "\t\tvertex " << -mag << " " << mag << " " << offset << std::endl;
                out << "\tend loop" << std::endl;
                out << "\nendfacet" << std::endl;
                out << "endsolid cube";

                offset += i.shape.cube.size;
                */

                /*
                off += i.shape.cube.size;
            }else if( i.type == "pyramid" ){
                // draw pyramid
                drawPyramid(i.color, off);
                off += 1.2f;
            }else if( i.type == "rect" ){
                // draw rect
                drawRect(i.shape.rect.height/2, i.shape.rect.length/2, i.shape.rect.width/2, i.color, off);
                off += i.shape.rect.height;
            }
        }
        */

        // close file
        //out.close();

    }

    emit downloaded();
    updateGL();
}



/* SET UNDO */
void MyGLWidget::initUndo(){
    if(!shapes.empty()){
        shapes.pop_back();
    }else{
        return;
    }
    printf("undoing ...\n");
    emit undo();
    updateGL();
}



// handles mouse press (not moved)
void MyGLWidget::mousePressEvent(QMouseEvent *event){
    lastPos = event->pos();
}

// handles mouse moves/clicks
void MyGLWidget::mouseMoveEvent(QMouseEvent *event){
    double dx = (event->x() - lastPos.x())/20.0;
    double dy = (event->y() - lastPos.y())/20.0;

    if (event->buttons() & Qt::LeftButton){
        x = x + dx;
        printf("x val is: %f\n", x);
    } else if (event->buttons() & Qt::RightButton){
        y = y + dy;
    }
    lastPos = event->pos();
}

// handle key presses
void MyGLWidget::keyPressEvent(QKeyEvent *e) {
    if(e->key() == Qt::Key_Q){
        printf("clicked q\n");
    }
    if(e->key() == Qt::Key_Escape){
        parent_widget->close();
    }
    if(e->key() == Qt::Key_Z){
        printf("z pressed\n");
        z = z + 1;
    }
}
